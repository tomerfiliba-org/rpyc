﻿"""
RPyC-Twisted integration, contributed by Noam Raphael 2007.12.09
"""
import sys

from twisted.internet.protocol import Factory, Protocol
from twisted.internet import reactor

from Rpyc.Stream import Stream
from Rpyc.Channel import Channel
from Rpyc.Connection import Connection


class TwistedSocketStream(Stream):
    def __init__(self, connection):
        # Note: This is a twisted connection - for example,
        # twisted.internet.tcp.Server
        self.connection = connection

        self.data = ''

    def fileno(self):
        return self.connection.socket.fileno()

    def pushdata(self, data):
        self.data += data

    def read(self, count):
        socket = self.connection.socket
        if count <= len(self.data):
            r = self.data[:count]
            self.data = self.data[count:]
            return r
        else:
            try:
                socket.setblocking(True)
                data = [self.data]
                count -= len(self.data)
                self.data = ''
                while count > 0:
                    buf = socket.recv(count)
                    if not buf:
                        raise EOFError()
                    data.append(buf)
                    count -= len(buf)
                r = ''.join(data)
                return r
            finally:
                socket.setblocking(False)

    def write(self, data):
       while data:
           count = self.connection.socket.send(data)
           data = data[count:]


class RpycProtocol(Protocol):

    def connectionMade(self):
        self.stream = TwistedSocketStream(self.transport)
        self.channel = Channel(self.stream)
        self.connection = Connection(self.channel)

    def dataReceived(self, data):
        self.stream.pushdata(data)
        self.connection.serve()


def main():
    if len(sys.argv) != 2:
        print >> sys.stderr, \
              "Usage: %s port" % sys.argv[0]
        sys.exit(1)
    port = int(sys.argv[1])

    factory = Factory()
    factory.protocol = RpycProtocol

    reactor.listenTCP(port, factory)
    reactor.run()

if __name__ == '__main__':
    main()

